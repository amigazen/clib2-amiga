#define VERSION		1
#define REVISION	213
#define DATE		"4.12.2016"
#define VERS		"m.lib 1.213"
#define VSTRING		"m.lib 1.213 (4.12.2016)\r\n"
#define VERSTAG		"\0$VER: m.lib 1.213 (4.12.2016)"
