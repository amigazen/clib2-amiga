#define VERSION		1
#define REVISION	213
#define DATE		"4.12.2016"
#define VERS		"amiga.lib 1.213"
#define VSTRING		"amiga.lib 1.213 (4.12.2016)\r\n"
#define VERSTAG		"\0$VER: amiga.lib 1.213 (4.12.2016)"
